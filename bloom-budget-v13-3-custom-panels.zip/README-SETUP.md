# Bloom Budget V10 — Shared Google Sign-In setup

Your Firebase Web configuration is already included in `firebase-config.js`.

## What you must do in Firebase Console

1. Authentication → Sign-in method → **Google: Enabled**, with a project support email.
2. Firestore Database → Rules → paste the entire `firestore.rules` file and **Publish**. Until you do, existing `allow read, write: if false` rules intentionally block all app data access. Never use `allow read, write: if true`.
3. Publish the app over HTTPS (GitHub Pages is one option). Put all files at the published site root. Do **not** upload personal financial CSV/JSON files to a public GitHub repository.
4. Authentication → Settings → Authorized domains → add your deployed domain (for GitHub Pages use `YOUR-USERNAME.github.io`, not a full URL).
5. Open the deployed HTTPS URL in Safari. More → Shared household → **Continue with Google**. Create household, invite Ronnie's exact Google account email, then privately share the household ID.
6. Ronnie opens the same URL in Safari, signs in with a different Google account, and enters the household ID to join.
7. After testing sign-in and cloud sync in Safari on both devices, try **Share → Add to Home Screen**. Google OAuth flows in iPhone standalone PWAs can behave differently; verify this on each device before relying on the Home Screen install.

## How sharing works

- Both users access the same `households/{id}` Firestore document. Firestore rules restrict read/write access to verified Google accounts on the household allowed-email list.
- Only the owner can modify the allowed-email list. Non-owners can edit the budget but cannot invite other users.
- Cloud data syncs when online. This implementation saves the entire budget document, so **simultaneous edits or offline changes can overwrite one another**. Save JSON backups regularly; test with example data before entering real financial details.
- The app is not yet live until you deploy the files, publish the rules, and test Google sign-in on the deployed HTTPS site. No bank integrations. No paid subscription or App Store publication required.
- Firebase Spark is a free tier with quotas, not a guarantee that third-party services will stay free forever.

## Current rent behavior

November payment of $1,700 is for **December rent**. December payment is for **January rent**. They appear under the payment month's cash flow, not double-counted under the month covered.
